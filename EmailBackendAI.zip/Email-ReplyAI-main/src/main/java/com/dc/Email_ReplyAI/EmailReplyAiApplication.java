package com.dc.Email_ReplyAI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailReplyAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmailReplyAiApplication.class, args);
	}

}
