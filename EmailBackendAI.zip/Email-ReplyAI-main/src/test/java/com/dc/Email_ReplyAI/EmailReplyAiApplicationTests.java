package com.dc.Email_ReplyAI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailReplyAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
